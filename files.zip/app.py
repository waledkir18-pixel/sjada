from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import json
import os
import uuid
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-change-in-production-!@#$%')

BASE_DIR      = os.path.dirname(__file__)
DATA_DIR      = os.path.join(BASE_DIR, 'data')
USERS_FILE    = os.path.join(DATA_DIR, 'users.json')
PRODUCTS_FILE = os.path.join(DATA_DIR, 'products.json')

def load_json(path, default):
    if not os.path.exists(path):
        return default
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('يجب تسجيل الدخول أولاً', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('يجب تسجيل الدخول أولاً', 'warning')
            return redirect(url_for('login'))
        if not session.get('is_admin'):
            flash('ليس لديك صلاحية الوصول', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        name     = request.form.get('name', '').strip()
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm  = request.form.get('confirm_password', '')
        users_data = load_json(USERS_FILE, {})
        if not name or not email or not password:
            flash('جميع الحقول مطلوبة', 'danger')
            return render_template('auth/signup.html')
        if password != confirm:
            flash('كلمتا المرور غير متطابقتين', 'danger')
            return render_template('auth/signup.html')
        if len(password) < 6:
            flash('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'danger')
            return render_template('auth/signup.html')
        if email in users_data:
            flash('البريد الإلكتروني مسجل مسبقاً', 'danger')
            return render_template('auth/signup.html')
        users_data[email] = {
            'id':         str(uuid.uuid4()),
            'name':       name,
            'email':      email,
            'password':   generate_password_hash(password),
            'is_admin':   False,
            'created_at': datetime.now().isoformat()
        }
        save_json(USERS_FILE, users_data)
        flash('تم إنشاء حسابك بنجاح! يمكنك تسجيل الدخول الآن', 'success')
        return redirect(url_for('login'))
    return render_template('auth/signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        email      = request.form.get('email', '').strip().lower()
        password   = request.form.get('password', '')
        users_data = load_json(USERS_FILE, {})
        user       = users_data.get(email)
        if user and check_password_hash(user['password'], password):
            session.permanent   = True
            session['user_id']  = user['id']
            session['name']     = user['name']
            session['email']    = email
            session['is_admin'] = user.get('is_admin', False)
            flash(f'مرحباً {user["name"]}!', 'success')
            return redirect(url_for('dashboard'))
        flash('البريد الإلكتروني أو كلمة المرور غير صحيحة', 'danger')
    return render_template('auth/login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('تم تسجيل الخروج بنجاح', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard/home.html')

@app.route('/store')
@login_required
def store():
    products_data = load_json(PRODUCTS_FILE, {'categories': [], 'items': []})
    return render_template('store/index.html', products=products_data.get('items', []))

@app.route('/webdesign')
@login_required
def webdesign():
    return render_template('web_design/index.html')

@app.route('/admin')
@admin_required
def admin_panel():
    products_data = load_json(PRODUCTS_FILE, {'categories': [], 'items': []})
    users_data    = load_json(USERS_FILE, {})
    users_count   = len(users_data)          # ✅ اسم مختلف تماماً
    return render_template("admin/panel.html", product_items=products_data.get("items", []), product_cats=products_data.get("categories", []), user_count=users_count)

@app.route('/admin/product/add', methods=['POST'])
@admin_required
def admin_add_product():
    name     = request.form.get('name', '').strip()
    price    = request.form.get('price', '0')
    category = request.form.get('category', '').strip()
    desc     = request.form.get('description', '').strip()
    if not name or not category:
        flash('اسم المنتج والتصنيف مطلوبان', 'danger')
        return redirect(url_for('admin_panel'))
    products_data = load_json(PRODUCTS_FILE, {'categories': [], 'items': []})
    if category not in products_data['categories']:
        products_data['categories'].append(category)
    products_data['items'].append({
        'id':          str(uuid.uuid4()),
        'name':        name,
        'price':       float(price),
        'category':    category,
        'description': desc,
        'created_at':  datetime.now().isoformat()
    })
    save_json(PRODUCTS_FILE, products_data)
    flash(f'تمت إضافة "{name}" بنجاح', 'success')
    return redirect(url_for('admin_panel'))

@app.route('/admin/product/delete/<product_id>', methods=['POST'])
@admin_required
def admin_delete_product(product_id):
    products_data = load_json(PRODUCTS_FILE, {'categories': [], 'items': []})
    products_data['items'] = [p for p in products_data['items'] if p['id'] != product_id]
    save_json(PRODUCTS_FILE, products_data)
    flash('تم حذف المنتج', 'info')
    return redirect(url_for('admin_panel'))

@app.route('/admin/product/edit/<product_id>', methods=['POST'])
@admin_required
def admin_edit_product(product_id):
    products_data = load_json(PRODUCTS_FILE, {'categories': [], 'items': []})
    for item in products_data['items']:
        if item['id'] == product_id:
            item['name']        = request.form.get('name', item['name']).strip()
            item['price']       = float(request.form.get('price', item['price']))
            item['category']    = request.form.get('category', item['category']).strip()
            item['description'] = request.form.get('description', item['description']).strip()
            break
    save_json(PRODUCTS_FILE, products_data)
    flash('تم تحديث المنتج بنجاح', 'success')
    return redirect(url_for('admin_panel'))

def seed_admin():
    users_data  = load_json(USERS_FILE, {})
    admin_email = 'admin@family.com'
    if admin_email not in users_data:
        users_data[admin_email] = {
            'id':         str(uuid.uuid4()),
            'name':       'زرمينة',
            'email':      admin_email,
            'password':   generate_password_hash('admin123'),
            'is_admin':   True,
            'created_at': datetime.now().isoformat()
        }
        save_json(USERS_FILE, users_data)
        print("✅ Admin account created → admin@family.com / admin123")

if __name__ == '__main__':
    seed_admin()
    app.run(debug=True, port=5000)
